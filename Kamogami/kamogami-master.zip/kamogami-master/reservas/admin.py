from django.contrib import admin
from reservas.models import servicio

admin.site.register(servicio)