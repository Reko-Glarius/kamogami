## Proyecto Gestión Ágil - 🔥 鴨神 🦆 

Proyecto semestral de la asginatura gestión agil UTEM 2021-1

Aplicación web realizada en django que permite a usuarios agendar horas de atención para _nombre\_empresa_ y otras cosas.

#### Autores
- Daniel Aguilera
- Nicolás Andrews
- Rodrigo Carmona
- Humberto Roman

